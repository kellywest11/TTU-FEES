
let api = null;

function startMeeting() {
  const roomNameInput = document.getElementById("roomName");
  const roomName = roomNameInput ? roomNameInput.value : "AttendanceRoom";

  if (api) {
    api.dispose();
  }

  const domain = "meet.jit.si";

  const options = {
    roomName: roomName,
    parentNode: document.getElementById("jitsi-container"),
    width: "100%",
    height: 600,
    configOverwrite: {
      startWithAudioMuted: true,
      startWithVideoMuted: true
    },
    interfaceConfigOverwrite: {
      SHOW_JITSI_WATERMARK: false
    }
  };

  api = new JitsiMeetExternalAPI(domain, options);
}

document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("joinMeetingBtn");
  if (btn) {
    btn.addEventListener("click", startMeeting);
  }
});
